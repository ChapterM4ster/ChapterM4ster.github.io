using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{

    public List<AudioSource> audioSources = new List<AudioSource>();
    public List<KeyCode> input = new List<KeyCode>();
    private IEnumerator previewInstance;


    public void PlayAudio(int audioListIndex)
    {
        audioSources[audioListIndex].Play();
    }

    private void Update()
    {
        for (int i = 0; i < input.Count; i++)
        {
            if (Input.GetKeyDown(input[i]))
            {
                
                audioSources[i].Play();
            }
        }
    }


    public void PlayPreview()
    {
        
        StartCoroutine(previewInstance = Preview());
    }

    public void StopPreview()
    {
        StopCoroutine(previewInstance);
    }

    private IEnumerator Preview()
    {
        audioSources[0].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[1].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[0].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[5].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[13].Play();
        yield return new WaitForSeconds(1.30f);
        audioSources[4].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[3].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[1].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[3].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[4].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[0].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[1].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[0].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[5].Play();
        yield return new WaitForSeconds(0.90f);
        audioSources[13].Play();
        yield return new WaitForSeconds(1.30f);
        audioSources[4].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[3].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[1].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[3].Play();
        yield return new WaitForSeconds(1.00f);
        audioSources[4].Play();

    }

}
