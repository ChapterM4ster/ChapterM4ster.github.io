﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ScoreManager : MonoBehaviour{

    public Text PlayerScoreText, Player2ScoreText;
    [HideInInspector] public int PlayerScore, Player2Score;


    // Start is called before the first frame update
    void Start() {
        
    }

    // Update is called once per frame
    void Update() {
        
    }

    public void IncreasePlayerScore() {
        PlayerScore++;
        PlayerScoreText.text = PlayerScore.ToString();
    }

    public void IncreasePlayer2Score()
    {
        Player2Score++;
        Player2ScoreText.text = Player2Score.ToString();
    }
}
