﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Ball : MonoBehaviour {

    private Rigidbody2D body;
    private float forceX, forceY;
    private ScoreManager scoreManager;
    private bool TowardsPlayer;
    private AudioSource audiosource;
    public AudioClip Bonksound, Goalsound;

    [HideInInspector] public float BallposY;

    // Start is called before the first frame update
    void Start() { 
        scoreManager = GameObject.FindObjectOfType<ScoreManager>();
        body = GetComponent<Rigidbody2D>();

        audiosource = GetComponent<AudioSource>();

        int roll = Random.Range(0, 2);
       
        forceX = -5;
       
        if (roll == 0){
            TowardsPlayer = false;
        } else {
            TowardsPlayer = true;
        }

        forceY = Random.Range(-2, 2);


        Moveball();
    }

    void Moveball(){

        if (TowardsPlayer == true){
            body.velocity = new Vector3(-forceX, -forceY);
        } else {
            body.velocity = new Vector3(forceX, forceY);
        }

    
    }

    private void OnCollisionEnter2D(Collision2D collider){
        
        if (collider.gameObject.name == "Top"){

            body.velocity += new Vector2(0, 3).normalized;

        } else if (collider.gameObject.name == "Bottom"){

            body.velocity += new Vector2(0, -3).normalized;

        }

        if (audiosource.clip != Bonksound) {
            audiosource.clip = Bonksound;
        }
       
        audiosource.Play();

    }

    void OnTriggerEnter2D (Collider2D trigger){

        if (trigger.name == "Right Goal") {
            scoreManager.IncreasePlayerScore();
            TowardsPlayer = false;

        } else if (trigger.name == "Left Goal") {
            scoreManager.IncreasePlayer2Score();
            TowardsPlayer = true;

        }

        audiosource.clip = Goalsound;
        audiosource.Play();

        RessetBall();

    }

    void RessetBall(){

        transform.localPosition = new Vector2(0, 0);
        Moveball();
    }


    // Update is called once per frame
    void Update(){

        BallposY = transform.localPosition.y;
        
    }
}
