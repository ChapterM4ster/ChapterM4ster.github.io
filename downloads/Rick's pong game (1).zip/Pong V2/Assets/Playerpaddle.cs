﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playerpaddle : MonoBehaviour{

    public float speed = 4f;
    private Vector3 upmost;
    private Vector3 downmost;
    private float minY, maxY;
    private float halfheight;

    private Ball ball;

    // Start is called before the first frame update
    void Start(){
        ball = GameObject.FindObjectOfType<Ball>();
        
        halfheight = GetComponent<SpriteRenderer>().sprite.bounds.extents.y;
       
        // houd de camera in het midden van het sher
        float Distance = transform.localPosition.z - Camera.main.transform.localPosition.z;
        downmost = Camera.main.ViewportToWorldPoint(new Vector3(0, 0 ,Distance));
        upmost = Camera.main.ViewportToWorldPoint(new Vector3(1, 1 ,Distance));

        minY = downmost.y + halfheight * 2;
        maxY = upmost.y - halfheight * 2;

    }

    // Update is called once per frame
    void Update(){
        if (gameObject.tag == "Player")
        {
            MovePlayer();

        }
        else if (gameObject.tag == "Player2"){
            MovePlayer2();
        }

    }

    void MovePlayer(){

        // leest de W en S toets van het toetsen bord
        if (Input.GetKey(KeyCode.W))
        {
            Moveplayerup();
        }
        else if (Input.GetKey(KeyCode.S))
        {
            Moveplayerdown();
        }

        float restrictY = Mathf.Clamp(transform.localPosition.y, minY, maxY);
        transform.localPosition = new Vector3(transform.localPosition.x, restrictY, transform.localPosition.z);
    }

    void MovePlayer2(){
        
        if (Input.GetKey(KeyCode.UpArrow))
        {
            Moveplayerup();
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            Moveplayerdown();
        }
        
        float restrictY = Mathf.Clamp(transform.localPosition.y, minY, maxY);
        transform.localPosition = new Vector3(transform.localPosition.x, restrictY, transform.localPosition.z);
    }

    void Moveplayerup(){
        transform.localPosition += Vector3.up * speed * Time.deltaTime;
    }

    void Moveplayerdown(){
        transform.localPosition += Vector3.down * speed * Time.deltaTime;
    }

}
